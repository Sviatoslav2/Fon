#include <fstream>
#include <iostream>
#include <thread>
#include <vector>
#include <fcntl.h>
#include <cstring>
#include <cmath>
#include <cmath>
#include <sstream>
#include <unistd.h>
#include <string>
#include <limits.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <boost/lexical_cast.hpp>
#include <boost/filesystem.hpp>
#include <stdio.h>
#include <stdlib.h>
#include <boost/algorithm/string.hpp>
#include "Myshell.h"
#include "File.h"
#include "Value.h"


namespace fs1 = boost::filesystem;
namespace fs2 = boost;

std::vector<std::string> split_cmd_line(std::istream& is) {
    std::string commandline;
    std::vector<std::string> parsed_command;
    std::getline(is, commandline);
    std::stringstream ss(commandline);
    std::string word;
    while (ss >> word) {
        parsed_command.push_back(word);
    }
    return parsed_command;
}



int main(int argc, char *argv[]){
    std::map<std::string, std::string>MapComand;
    std::map<std::string, std::string>Map;
    bool FileCon = false;
    bool ExitKey = true;
    int ERROR = 0;
    int NumberMexitMcdMerrnoMpwd = 0;
    bool MexitKey = false;
    std::string MainDirectory = get_current_directory();
    std::vector<std::string> Vector;
    std::vector<std::string> VectorOfFile;
    for(int i = 1; i < argc;++i){
        Vector.emplace_back(argv[i]);
    }
    if(Vector.size() == 1) {
        ERROR = File(Vector[0],ERROR,ExitKey, MainDirectory,Map,MapComand);
    }




    while (ExitKey) {
        std::cout <<"#"<< get_current_directory() + " $";
        auto dataFromConsol = split_cmd_line(std::cin);

        for(auto& a: dataFromConsol){
            std::cout <<a<< std::endl;
        }

        Map = MapOfValue(dataFromConsol,Map);
        if(dataFromConsol.size() != 0){

            NumberMexitMcdMerrnoMpwd = HelpRice(dataFromConsol);
            if(NumberMexitMcdMerrnoMpwd == 6 && dataFromConsol.size() >= 2){
                ERROR = File(dataFromConsol[1],ERROR,ExitKey, MainDirectory,MapComand,Map);
            }
            else{
                auto dataFromConsolNEW = VectorWithoutElementsWithSimbol(dataFromConsol,std::string("#"));
                if(dataFromConsolNEW.size() > 0){
                    ERROR = Consol(ExitKey,MainDirectory,ERROR,dataFromConsolNEW,MapComand,Map);
                }

            }

        }
    }
}