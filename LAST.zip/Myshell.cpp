//
// Created by Admin on 31.05.2018.
//

#include <fstream>
#include <iostream>
#include <thread>
#include <vector>
#include <fcntl.h>
#include <cstring>
#include <cmath>
#include <cmath>
#include <sstream>
#include <unistd.h>
#include <string>
#include <limits.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <boost/lexical_cast.hpp>
#include <boost/filesystem.hpp>
#include <stdio.h>
#include <stdlib.h>
#include <boost/algorithm/string.hpp>
#include "File.h"
#include "Value.h"


using std::cout;
using std::cerr;
using std::endl;
using std::string;
using std::vector;
using std::strlen;
using std::strcat;



namespace fs1 = boost::filesystem;
namespace fs2 = boost;

std::string get_current_directory(){
    char buf[PATH_MAX+1];
    getcwd(buf, sizeof(buf));
    return std::string(buf);
}


void helpMcd(){
    std::cout <<">Afther you writhe Mcd.\n>Please write yor Path with /mnt/c/...(linux notation).\n>If name of Path will be incorrect then No such file in directory.\n>And exit process.\n>Or you can -h/--help for help"<< std::endl;
}

void helpMpwd(){
    std::cout <<">Afther you writhe Mpwd.\n>You will see your curent directory."<< std::endl;

}

void helpMexit(){
    std::cout <<">Afther you writhe Mpwd.\n"
                ">Please write : \n"
                ">>>mexit number\n"
                ">>>mexit -h for more information.\n"
                ">>>mexit --help"<< std::endl;

}

void helpMerrno(){
    std::cout <<"Return the number of error( of the last operation)"<< std::endl;
}

int change_directory(char *dirPATH){
    int erno1 = 0;
    erno1 = chdir(dirPATH);
    return erno1;
}
int changeDirectory(std::string Directory){
    const char *cstr = Directory.c_str();
    int erno = change_directory((char *) cstr);
    return erno;
}


int is_it_stdout(std::vector<std::string> dataFromConsol1,std::string Simbol){
    for(int i = 0; i < dataFromConsol1.size(); ++i){
        if(Simbol == dataFromConsol1[i]){
            return i;
        }
    }
    return -1;
}


int min_position(int positionW,int positionE){

    if(positionE < positionW){
        return positionE;
    }
    else{
        return positionW;
    }
}

int ToDoFunctionInTheseDirectory(std::vector<std::string> dataFromConsol1){
    std::vector<std::string> dataFromConsol;
    //auto positionW = is_it_stdout(dataFromConsol1,std::string(">"));
    //auto positionE = is_it_stdout(dataFromConsol1,std::string("2>"));
    //a//uto positionLast = is_it_stdout(dataFromConsol1,std::string("2>&1"));
    auto position = is_it_stdout(dataFromConsol1,std::string(">"));

    std::string NameOfFile = dataFromConsol1[position+1];
    if(position != -1){
        for(size_t i = 0; i < position; ++i){
            std::cout<<dataFromConsol1[i]<<std::endl;
            dataFromConsol.emplace_back(dataFromConsol1[i]);

        }
    }
    else{
        dataFromConsol = dataFromConsol1;
    }

    if(dataFromConsol[0] != std::string("ls")){

        dataFromConsol[0] = dataFromConsol[0] + ".exe";
    }

    int ERROR = 0;
    int args_n = dataFromConsol.size();

    char **args = static_cast<char**>(malloc( (args_n + 1) * sizeof(char*)));

    //args[0] = arg1;
    for(int i = 0; i<dataFromConsol.size();i++){
        args[i] = (char *) dataFromConsol[i].c_str();
    }
    args[dataFromConsol.size()] = 0;
    string victim_name(args[0]);


    pid_t parent = getpid();
    pid_t pid = fork();

    int file_desc;

    if (pid == -1)
    {
        std::cerr << "Failed to fork()" << std::endl;
        //exit(EXIT_FAILURE);
        ERROR = errno; }
    else if (pid > 0)
    {
        // We are parent process
        int status;
        waitpid(pid, &status, 0);

        ERROR = errno;
    }
    else {
        if(position != -1){
            file_desc = open(NameOfFile.c_str(), O_WRONLY | O_APPEND);
            dup2(file_desc, STDOUT_FILENO);
        }

        execvpe(victim_name.c_str(), args, environ);

        if(errno == 14){
            ToDoFunctionInTheseDirectory(dataFromConsol);
        }

        else{
            cerr << "Parent: Failed to execute " << victim_name << " \n\tCode: " << errno << endl;
        }
        ERROR = errno;
    }
    close(file_desc);
    return ERROR;

}



int HelpRice(std::vector<std::string> dataFromConsol){
    int NumberMexitMcdMerrnoMpwd = 0;
    if(dataFromConsol[0] == "mexit"){
        NumberMexitMcdMerrnoMpwd = 1;
    }
    else if(dataFromConsol[0] == "mcd"){
        NumberMexitMcdMerrnoMpwd = 2;
    }
    else if(dataFromConsol[0] == "merrno"){
        NumberMexitMcdMerrnoMpwd = 3;
    }
    else if(dataFromConsol[0] == "mpwd"){
        NumberMexitMcdMerrnoMpwd = 4;
    }
    else if(dataFromConsol[0] == "mycat"){
        NumberMexitMcdMerrnoMpwd = 5;
    }
    else if(dataFromConsol[0] == "."){
        NumberMexitMcdMerrnoMpwd = 6;
    }
    else if(dataFromConsol[0] == "mecho"){
        NumberMexitMcdMerrnoMpwd = 7;
    }


    else if(dataFromConsol[0] == "myls"){
        NumberMexitMcdMerrnoMpwd = 8;
    }
    else if(IsElem(dataFromConsol)){// VAR =
        NumberMexitMcdMerrnoMpwd = 9;
    }
    else if (dataFromConsol[0] == "mexport"){
        NumberMexitMcdMerrnoMpwd = 10;
    }
    else if(dataFromConsol[0] == "/bin/ls"){
        NumberMexitMcdMerrnoMpwd = 11;
    }
    else if(dataFromConsol[0] == "ls"){

        NumberMexitMcdMerrnoMpwd = 12;
    }


    if(not (NumberMexitMcdMerrnoMpwd == 0)){
        for(int i = 1; i < dataFromConsol.size(); i++){
            if(dataFromConsol[1] == "-h" || dataFromConsol[1] == "--help"){
                if(NumberMexitMcdMerrnoMpwd == 1){
                    helpMexit();
                }
                else if(NumberMexitMcdMerrnoMpwd == 2){
                    helpMcd();
                }
                else if(NumberMexitMcdMerrnoMpwd == 3){
                    helpMerrno();
                }
                else if(NumberMexitMcdMerrnoMpwd == 4){
                    helpMpwd();
                }
            }
        }
    }
    return NumberMexitMcdMerrnoMpwd;
}


int castStringToInt(std::string NumberString){
    int i = 0;
    try {

        i = boost::lexical_cast<int>( NumberString.c_str());

    }
    catch( boost::bad_lexical_cast const& ){
        std::cout<<"You used incorrect number after Mexit"<<std::endl;

    }

    return i;
}


void Mexit(std::vector<std::string> dataFromConsol){

    if(dataFromConsol.size() == 2){

        exit(castStringToInt(dataFromConsol[1]));
    }
    else if (dataFromConsol.size() == 1){
        exit(0);
    }
    else if(dataFromConsol.size() > 2){
        std::cout<<"Incorrect parameter for Mexit"<<std::endl;
    }
}

int Mcd(std::vector<std::string> dataFromConsol,int ERROR,std::map<std::string, std::string>& Map){
    bool key = false;
    int position = 0;
    for(int i = 0; i < dataFromConsol.size();++i){
        key = IsSimbolInString(dataFromConsol[i],std::string("$"));
    }
    if(dataFromConsol.size() >= 2){
        if(key){
            std::cout<<dataFromConsol[position]<<std::endl;
            dataFromConsol[position] = Map[dataFromConsol[position]];
        }
        ERROR = changeDirectory(dataFromConsol[1]);
    }
    else{
        std::cout<<"You used incorrect argument"<<std::endl;
        ERROR = 1;
    }
    return ERROR;
}

int Mpwd(std::vector<std::string> dataFromConsol,int ERROR){
    if(dataFromConsol.size() == 1){
        std::cout <<get_current_directory()<< std::endl;
    }
    else{
        std::cout<<"You used incorrect argument"<<std::endl;
        ERROR = 1;
    }
    return ERROR;
}


int Consol(bool ExitKey,std::string MainDirectory, int ERROR, std::vector<std::string>dataFromConsol,std::map<std::string, std::string>& MapComand,std::map<std::string, std::string>& Map){


    for(int i = 1; i < dataFromConsol.size();++i){
        if(IsSimbolInString(dataFromConsol[i],std::string("$"))){
            dataFromConsol[i] = Map[dataFromConsol[i]];
        }
    }

    auto NumberMexitMcdMerrnoMpwd = HelpRice(dataFromConsol);
    if(NumberMexitMcdMerrnoMpwd == 1){//Mexit
        Mexit(dataFromConsol);
    }
    else if(NumberMexitMcdMerrnoMpwd == 2){//Mcd
        ERROR = Mcd(dataFromConsol,ERROR,Map);
    }
    else if(NumberMexitMcdMerrnoMpwd == 3){//Merno
        std::cout<<ERROR<<std::endl;
    }
    else if (NumberMexitMcdMerrnoMpwd == 4){//Mpwd
        Mpwd(dataFromConsol,ERROR);
    }
    else if(NumberMexitMcdMerrnoMpwd == 5){
        auto directory = get_current_directory();
        changeDirectory(MainDirectory);
        dataFromConsol[0] = "./"+dataFromConsol[0];//
        ERROR = ToDoFunctionInTheseDirectory(dataFromConsol);
        changeDirectory(directory);
    }

    else if(NumberMexitMcdMerrnoMpwd == 7){//mecho
        //std::cout<<"MECHO"<<std::endl;

        bool key = true;
        for (std::map<std::string,std::string>::iterator it=MapComand.begin(); it!=MapComand.end(); ++it){
            if(it->first == dataFromConsol[1]){
                std::cout<<dataFromConsol[1]<<" == "<<MapComand[dataFromConsol[1]]<<std::endl;
                key = false;
            }
        }
        if(key){
            std::cout<<dataFromConsol[1]<<std::endl;
        }


    }

    else if(NumberMexitMcdMerrnoMpwd == 9){
        Map = MapOfValue(dataFromConsol,Map);

    }
    else if (NumberMexitMcdMerrnoMpwd == 10){
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////mexport
        //MapComand[dataFromConsol[1]] = dataFromConsol[3];
        MapComand = MapOfValue(dataFromConsol,MapComand);

    }

    else if(NumberMexitMcdMerrnoMpwd == 11 || NumberMexitMcdMerrnoMpwd == 12 || NumberMexitMcdMerrnoMpwd == 8){
        for(int i = 1; i < dataFromConsol.size();++i){
            if(IsSimbolInString(dataFromConsol[i],std::string("$"))){
                dataFromConsol[i] = MapComand[dataFromConsol[i]];
            }
        }
        dataFromConsol[0] = "ls";
        ERROR = ToDoFunctionInTheseDirectory(dataFromConsol);
    }
    else if (NumberMexitMcdMerrnoMpwd == 0){

        for(int i = 1; i < dataFromConsol.size();++i){
            if(IsSimbolInString(dataFromConsol[i],std::string("$"))){
                for (std::map<std::string,std::string>::iterator it=MapComand.begin(); it!=MapComand.end(); ++it){
                    if(it->first == dataFromConsol[i]){
                        dataFromConsol[i] = MapComand[dataFromConsol[i]];
                    }
                }
            }
        }

        auto Dir = get_current_directory();
        auto file = FileFinder(dataFromConsol[0]);
        dataFromConsol[0] = "./" + file.filename().string();
        ERROR = ToDoFunctionInTheseDirectory(dataFromConsol);
        changeDirectory(Dir);
    }
    return ERROR;
}

